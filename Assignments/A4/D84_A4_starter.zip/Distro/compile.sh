g++ -O3 -c -g NeuralNets.c
g++ -O3 -g *.o -lm -o NeuralNets

